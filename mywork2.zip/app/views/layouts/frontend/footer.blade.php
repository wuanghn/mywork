 				<!-- <div class="container wa_footer">
 					<div class="wa_wrap_footer">
 						<a href="#">Về chúng tôi</a>
 						<a href="#">Liên hệ</a>
 						<a href="#">Tin tức</a>
 						<a href="#">Trợ giúp</a>
 						<a href="#">Thỏa thuận sử dụng</a>
 						<a href="#">Quy định bảo mật</a>
 					</div>
 				</div> -->


 			<div class="wa_wrap_new_footer">
 				<div class="container">
 					<div class="row">
 						<div class="col-md-3">
 							<img src="{{url('public/frontend/img/logo_footer.png')}}">
 							<p>Copyright © Navigos Group Vietnam Joint Stock Company 
130 Suong Nguyet Anh Street, Ben Thanh Ward, District 1, Ho Chi Minh City, Vietnam</p>
 						</div>
 						<div class="col-md-3 wa_hide_footer_respo">
 							<h3>Introduce</h3>
 							<ul class="nav nav-pills nav-stacked">
 							  	<li><a href="#">About Us</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Press Corner</a></li>
								<li><a href="#">FAQ</a></li>
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privacy Statement</a></li>
 							</ul>
 						</div>
 						<div class="col-md-3 col-md-offset-3 wa_social wa_hide_footer_respo">
 							<h3>Subscribe to Us</h3>
 							<div class="col-md-6">
 								<a href="#" class="box_social">
 									<i class="fa fa-facebook fa-lg"></i>
 								</a>
 							</div>
 							<div class="col-md-6">
 								<a href="#" class="box_social">
 									<i class="fa fa-linkedin-square fa-lg"></i>
 								</a>
 							</div>
 							<div class="col-md-6">
 								<a href="#" class="box_social">
 									<i class="fa fa-google-plus fa-lg"></i>
 								</a>
 							</div>
 							<div class="col-md-6">
 								<a href="#" class="box_social">
 									<i class="fa fa-twitter fa-lg"></i>
 								</a>
 							</div>
 						</div>
 					</div>
 				</div>
 			</div>