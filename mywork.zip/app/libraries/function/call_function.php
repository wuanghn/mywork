<?php

	/*
	
			Functions callback for all controllers
			Author: Wa
			Date: 02/04/2015  

	*/



function display_messages() {
	return "wa Callback";
}